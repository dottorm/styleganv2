import os
import string

greetTimes = 2
print("hello %s world!" % greetTimes)
