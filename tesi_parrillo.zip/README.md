E' necessario installare diversi pacchetti per poter compilare il progetto (in un'installazione standard di TeXLive si può usare il tool tlmgr)
Il principale è toptesi, bundle LaTex del Politecnico di Torino. 
Alcuni dei pacchetti necessari:

tlmgr install toptesi blindtext wrapfig paralist multirow algorithms csquotes biblatex biber inconsolata lstaddons

Per compilare il progetto è stato predisposto un Makefile. 

Per ottenere il PDF:

make

Per pulire completamente i file intermedi e il PDF:

make clean

Per pulire gli intermedi ma non il PDF:

make cleannopdf

